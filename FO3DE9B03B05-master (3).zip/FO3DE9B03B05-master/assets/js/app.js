function createBackdrop() {
	var backdrop = document.createElement("div");
	backdrop.classList.add("backdrop");
	document.body.appendChild(backdrop);
}

function removeBackdrop() {
	var backdrop = document.getElementsByClassName("backdrop");
	for (var i = 0; i < backdrop.length; i++) {
		backdrop[i].remove();
	}
}

function changeStatus() {
	createBackdrop();
	var el = document.getElementById("statusSelector");
	el.classList.add("active");
}

function hideStatusSelector() {
	removeBackdrop();
	var el = document.getElementById("statusSelector");
	el.classList.remove("active");
}

function readConversation() {
	createBackdrop();
	var el = document.getElementById("pastConversation");
	el.classList.add("active");
}

function hideConversationReader() {
	removeBackdrop();
	var el = document.getElementById("pastConversation");
	el.classList.remove("active");
}